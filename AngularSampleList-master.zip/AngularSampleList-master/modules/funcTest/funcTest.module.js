(function () { 
	'use strict';
    angular.module('crossApp.funcTest',['crossApp.common']);
})();