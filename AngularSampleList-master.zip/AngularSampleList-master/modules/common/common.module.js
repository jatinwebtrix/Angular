/**
 * The main Module 
 *
 * @type {angular.Module}
 */

(function () { 
	'use strict';
	angular.module('crossApp.common', ['ngSanitize']);
})();
