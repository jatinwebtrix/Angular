(function () { 
	'use strict';
    angular.module('crossApp.home',[
                                    'ngSanitize'
                                    ]);
})();