(function () { 
	'use strict';
    angular.module('crossApp.metrics',['crossApp.common']);
})();