(function () { 
	'use strict';
    angular.module('crossApp.unitTest',['crossApp.common']);
})();